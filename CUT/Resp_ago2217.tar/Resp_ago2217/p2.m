options = odeset('RelTol', 1e-4, 'AbsTol', [1e-4 1e-4 1e-5]);
[T,Y] = ode45(@rigido, [0 12], [0 1 1], options);

plot(T, Y(:,1),'-', T, Y(:,2), '-', T, Y(:,3))
%, Y(:,3), '.')

