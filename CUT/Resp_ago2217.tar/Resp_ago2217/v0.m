function t = v0(t)
   t = cos(t)
   